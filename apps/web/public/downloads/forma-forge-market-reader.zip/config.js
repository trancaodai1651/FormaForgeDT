globalThis.FORMAFORGE_MARKET_CONFIG = Object.freeze({"supabaseUrl":"https://caghwzzhuqfnybcfqxph.supabase.co","anonKey":"sb_publishable_cIrWRT4-UL2Dr5ZAJeH_gg_90kTaDPz"});
